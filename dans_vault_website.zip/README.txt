# Dan's Vault Website

A responsive static storefront demo for Dan's Vault.

## Included
- Responsive homepage
- Product catalogue and category filters
- Basket stored in browser localStorage
- Mobile layout
- Winter-focused merchandising
- Product-photo styling based on the Dan's Vault wooden-floor reference

## Before taking real orders
1. Replace the demo products/prices/images in `script.js`.
2. Connect a real checkout/payment provider such as Stripe or Shopify.
3. Add your real returns, delivery and contact information.
4. Connect a custom domain and hosting.
